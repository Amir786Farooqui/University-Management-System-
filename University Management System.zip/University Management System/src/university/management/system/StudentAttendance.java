/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university.management.system;

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StudentAttendance extends JFrame implements ActionListener{
    
    JLabel l1,l2,l3,l4,l5,l6,l7;
    JTextField t1,t2,t3,t4,t5,t6,t7;
    JButton b1,b2;
    Choice c2,fh,sh;
    
    StudentAttendance(){
    	setResizable(false);
    	setTitle("Attendance ");
        try{
            conn c = new conn();
            ResultSet rs = c.s.executeQuery("select * from student");
            while(rs.next()){
                c2.add(rs.getString("rollno"));    
            }
      
      
       }catch(Exception e){ }
         SpringLayout springLayout = new SpringLayout();
         getContentPane().setLayout(springLayout);
         JLabel label = new JLabel("Select Roll Number");
         springLayout.putConstraint(SpringLayout.NORTH, label, 11, SpringLayout.NORTH, getContentPane());
         springLayout.putConstraint(SpringLayout.WEST, label, 24, SpringLayout.WEST, getContentPane());
         springLayout.putConstraint(SpringLayout.SOUTH, label, 60, SpringLayout.NORTH, getContentPane());
         springLayout.putConstraint(SpringLayout.EAST, label, 181, SpringLayout.WEST, getContentPane());
         getContentPane().add(label);
          c2 = new Choice();
          springLayout.putConstraint(SpringLayout.NORTH, c2, 28, SpringLayout.NORTH, getContentPane());
          springLayout.putConstraint(SpringLayout.WEST, c2, 202, SpringLayout.WEST, getContentPane());
          springLayout.putConstraint(SpringLayout.EAST, c2, 364, SpringLayout.WEST, getContentPane());
          getContentPane().add(c2);
        
          l1 = new JLabel("First Half");
          springLayout.putConstraint(SpringLayout.NORTH, l1, 37, SpringLayout.SOUTH, label);
          springLayout.putConstraint(SpringLayout.WEST, l1, 24, SpringLayout.WEST, getContentPane());
          l1.setHorizontalAlignment(SwingConstants.CENTER);
           getContentPane().add(l1);
        
        l2 = new JLabel("Second Half");
        springLayout.putConstraint(SpringLayout.EAST, l1, -21, SpringLayout.WEST, l2);
        springLayout.putConstraint(SpringLayout.SOUTH, c2, -49, SpringLayout.NORTH, l2);
        springLayout.putConstraint(SpringLayout.EAST, l2, 364, SpringLayout.WEST, getContentPane());
        springLayout.putConstraint(SpringLayout.NORTH, l2, 97, SpringLayout.NORTH, getContentPane());
        springLayout.putConstraint(SpringLayout.WEST, l2, 202, SpringLayout.WEST, getContentPane());
        l2.setHorizontalAlignment(SwingConstants.CENTER);
        l2.setVerticalAlignment(SwingConstants.TOP);
         getContentPane().add(l2);
        fh = new Choice();
        springLayout.putConstraint(SpringLayout.NORTH, fh, 38, SpringLayout.SOUTH, l1);
        springLayout.putConstraint(SpringLayout.WEST, fh, 24, SpringLayout.WEST, getContentPane());
        springLayout.putConstraint(SpringLayout.EAST, fh, 181, SpringLayout.WEST, getContentPane());
        fh.add("Present");
        fh.add("Absent");
        fh.add("Leave");
        getContentPane().add(fh);
        sh = new Choice();
        springLayout.putConstraint(SpringLayout.SOUTH, l2, -38, SpringLayout.NORTH, sh);
        springLayout.putConstraint(SpringLayout.NORTH, sh, 149, SpringLayout.NORTH, getContentPane());
        springLayout.putConstraint(SpringLayout.WEST, sh, 202, SpringLayout.WEST, getContentPane());
        springLayout.putConstraint(SpringLayout.EAST, sh, 364, SpringLayout.WEST, getContentPane());
        sh.add("Present");
        sh.add("Absent");
        sh.add("Leave");
        getContentPane().add(sh);
        
         b1 =new JButton("Submit");
         springLayout.putConstraint(SpringLayout.SOUTH, fh, -151, SpringLayout.NORTH, b1);
         springLayout.putConstraint(SpringLayout.WEST, b1, 24, SpringLayout.WEST, getContentPane());
         springLayout.putConstraint(SpringLayout.SOUTH, b1, 345, SpringLayout.NORTH, getContentPane());
         springLayout.putConstraint(SpringLayout.EAST, b1, 0, SpringLayout.EAST, label);
         b1.setBackground(Color.BLACK);
         b1.setForeground(Color.WHITE);
         getContentPane().add(b1);
         
         b1.addActionListener(this);
        
        getContentPane().setBackground(new Color(153, 204, 204));
         
         b2 = new JButton("Cancel");
         springLayout.putConstraint(SpringLayout.NORTH, b2, 320, SpringLayout.NORTH, getContentPane());
         springLayout.putConstraint(SpringLayout.WEST, b2, 21, SpringLayout.EAST, b1);
         springLayout.putConstraint(SpringLayout.SOUTH, b2, -77, SpringLayout.SOUTH, getContentPane());
         springLayout.putConstraint(SpringLayout.EAST, b2, -47, SpringLayout.EAST, getContentPane());
         springLayout.putConstraint(SpringLayout.SOUTH, sh, -151, SpringLayout.NORTH, b2);
         springLayout.putConstraint(SpringLayout.NORTH, b1, 0, SpringLayout.NORTH, b2);
         b2.setBackground(Color.BLACK);
         b2.setForeground(Color.WHITE);
         getContentPane().add(b2);
         b2.addActionListener(this);
        
        setVisible(true);
        setSize(427,461);
        setLocation(600,200);
       
    }
    
    public void actionPerformed(ActionEvent ae){
       
        String f = fh.getSelectedItem();
        String s = sh.getSelectedItem();
        String dt = new java.util.Date().toString();
        String id=c2.getSelectedItem();
        String qry = "insert into attendance_student values("+ id +",'"+dt+"','"+f+"','"+s+"')";
       
        try{
            conn c1 = new conn();
            c1.s.executeUpdate(qry);
            JOptionPane.showMessageDialog(null,"Attendance confirmed");
            this.setVisible(false);
        }catch(Exception ee){
            ee.printStackTrace();
        }
    }
    
    public static void main(String s[]){
        new StudentAttendance();
    }
}
