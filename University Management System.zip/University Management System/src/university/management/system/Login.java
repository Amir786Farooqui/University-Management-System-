/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university.management.system;


import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

public class Login extends JFrame implements ActionListener{

    JFrame f;
    JLabel l1,l2;
    JTextField t1;
    JPasswordField t2;
    JButton b1,b2;

    Login(){

        super("Login");
        setResizable(false);

        setBackground(Color.white);

        l1 = new JLabel("Username :");
        l1.setFont(new Font("Tahoma", Font.BOLD, 11));
        
        l2 = new JLabel("Password :");
        l2.setFont(new Font("Tahoma", Font.BOLD, 11));
 
        t1=new JTextField();

        t2=new JPasswordField();
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/second.png"));
        Image i2 = i1.getImage().getScaledInstance(200,200,Image.SCALE_DEFAULT);
        ImageIcon i3 =  new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);


        b1 = new JButton("Login");
        b1.setFont(new Font("serif",Font.BOLD,15));
        b1.addActionListener(this);
        b1.setBackground(new Color(255, 204, 255));
        b1.setForeground(new Color(0, 153, 0));

        b2=new JButton("Cancel");
        b2.setFont(new Font("serif",Font.BOLD,15));
        b2.setBackground(new Color(255, 204, 255));
        b2.setForeground(new Color(153, 0, 0));

        b2.addActionListener(this);
        
        getContentPane().setBackground(new Color(153, 204, 255));
        GroupLayout groupLayout = new GroupLayout(getContentPane());
        groupLayout.setHorizontalGroup(
        	groupLayout.createParallelGroup(Alignment.LEADING)
        		.addGroup(groupLayout.createSequentialGroup()
        			.addGap(40)
        			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
        				.addComponent(l1, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)
        				.addComponent(l2, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)
        				.addComponent(b1, GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE))
        			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
        				.addComponent(t1, GroupLayout.PREFERRED_SIZE, 159, GroupLayout.PREFERRED_SIZE)
        				.addComponent(t2, GroupLayout.PREFERRED_SIZE, 159, GroupLayout.PREFERRED_SIZE)
        				.addGroup(groupLayout.createSequentialGroup()
        					.addPreferredGap(ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
        					.addComponent(b2, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)))
        			.addGap(54)
        			.addComponent(l3, GroupLayout.PREFERRED_SIZE, 184, GroupLayout.PREFERRED_SIZE)
        			.addGap(27))
        );
        groupLayout.setVerticalGroup(
        	groupLayout.createParallelGroup(Alignment.LEADING)
        		.addGroup(groupLayout.createSequentialGroup()
        			.addGap(29)
        			.addComponent(t1, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
        			.addGap(20)
        			.addComponent(t2, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
        			.addPreferredGap(ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
        			.addComponent(b2, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
        			.addGap(82))
        		.addGroup(groupLayout.createSequentialGroup()
        			.addGap(20)
        			.addComponent(l1, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
        			.addGap(11)
        			.addComponent(l2, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
        			.addGap(40)
        			.addComponent(b1, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(82, Short.MAX_VALUE))
        		.addGroup(groupLayout.createSequentialGroup()
        			.addComponent(l3, GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
        			.addContainerGap())
        );
        getContentPane().setLayout(groupLayout);

        setVisible(true);
        setSize(600,300);
        setLocation(500,300);

    }

    public void actionPerformed(ActionEvent ae){

        try{
            conn c1 = new conn();
            String u = t1.getText();
            String v = t2.getText();
            
            String q = "select * from login where username='"+u+"' and password='"+v+"'";
            
            ResultSet rs = c1.s.executeQuery(q); 
            if(rs.next()){
                new Project().setVisible(true);
                setVisible(false);
            }else{
                JOptionPane.showMessageDialog(null, "Invalid login");
                setVisible(false);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void main(String[] arg){
        Login l = new Login();
    }
}